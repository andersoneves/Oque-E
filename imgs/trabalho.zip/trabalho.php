<?php
session_start();
    require_once 'funcao.php';

    if(!isset($_SESSION["auth"])){
        $email=$_POST["email"];
        $senha=$_POST["senha"];
        login($email,$senha);
    }
    
?>


<!DOCTYPE html>
<html>
 <head>
        <meta charset = "utf - 8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link real = 'stylesheet' href = 'style.css' tupe= 'text/css'/>
        <title>Autendicando Usuario</title>
        <link href = "style.css" rel = "stylesheet" />
    </head>
        <body>
            <div>    
                <h1>Autenticação do Usuario</h1>
                    <fieldset>
                        <legend><h2>Login do Usuario</h2></legend>
                        <form method = "POST" action = "login.php">
                           Email :<br/> 
                           <input type = "text" name = "email" placeholder = "Informe seu e-mail" required/><br/>
                           Senha :<br/>
                           <input type = "password" name = "senha" placeholder = "Informe sua senha" required /><br><br/>
                           <input type="checkbox" /> Salvar dados <br/><br/>
                           <a href= "Esqueceu senha?"target="_blank">Esqueceu senha?</a><br/><br/>
                           <input type = "submit" value= "Enviar"/>
                        </form>
                 </fieldset>
            </div>  
        </body>
</html>

    