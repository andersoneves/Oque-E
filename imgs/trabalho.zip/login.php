<?php
session_start();
    require_once 'funcao.php';

    if(!isset($_SESSION["auth"])){
        $email=$_POST["email"];
        $senha=$_POST["senha"];
        login($email,$senha);
    }
    
?>
  <!DOCTYPE html>
  <html>
  <head>
    <title>Usuario Autenticado</title>
  </head>
 <body>
       <?php
        echo"<h1>email".$_COOKIE["email"]."logado com sucesso!</h1>";
        echo"<h1>A senha do usuario é: ".$_COOKIE["senha"]."</h1>";
     ?>
    <a href="logout.php">sair</a>
 </body>
 </html>
