<?php
    function autenticar($email,$senha){
        if($email=='ana@gmail.com'&&$senha==1234){
            setcookie("email",$email,time()+3700);
            return true;
        }else{
            return false;
        }
    }
?>







